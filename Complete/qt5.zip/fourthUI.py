from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_FourthWindow(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(1024, 600)
        Form.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.barcordlabe_1 = QtWidgets.QLabel(parent=Form)
        self.barcordlabe_1.setGeometry(QtCore.QRect(20, 110, 500, 470))
        self.barcordlabe_1.setStyleSheet("QLabel{\n"
"    color: black;\n"
"    background-color: white;\n"
"    border: 2px solid rgb(0,0,0);\n"
"}")
        self.barcordlabe_1.setObjectName("barcordlabe_1")
        self.mainbutton_3 = QtWidgets.QPushButton(parent=Form)
        self.mainbutton_3.setGeometry(QtCore.QRect(20, 10, 101, 60))
        self.mainbutton_3.setStyleSheet("QPushButton{\n"
"    color: white;\n"
"    background-color: rgb(0, 85, 255);;\n"
"    border: 2px solid rgb(58, 134, 255);\n"
"    border-radius: 20px;\n"
"    font-size: 16pt;  \n"
"    font-weight: bold; \n"
"}")
        self.mainbutton_3.setObjectName("mainbutton_3")
        self.cashpagebutton_3 = QtWidgets.QPushButton(parent=Form)
        self.cashpagebutton_3.setGeometry(QtCore.QRect(140, 10, 101, 60))
        self.cashpagebutton_3.setStyleSheet("QPushButton{\n"
"    color: black;\n"
"    background-color: white;\n"
"    border: 2px solid rgb(58, 134, 255);\n"
"    border-radius: 20px;\n"
"    font-size: 16pt;  \n"
"    font-weight: bold; \n"
"}")
        self.cashpagebutton_3.setObjectName("cashpagebutton_3")
        self.cataloguebutton_3 = QtWidgets.QPushButton(parent=Form)
        self.cataloguebutton_3.setGeometry(QtCore.QRect(260, 10, 100, 60))
        self.cataloguebutton_3.setStyleSheet("QPushButton{\n"
"    color: black;\n"
"    background-color: white;\n"
"    border: 2px solid rgb(58, 134, 255);\n"
"    border-radius: 20px;\n"
"    font-size: 16pt;  \n"
"    font-weight: bold; \n"
"}")
        self.cataloguebutton_3.setObjectName("cataloguebutton_3")
        self.barcordlabe_2 = QtWidgets.QLabel(parent=Form)
        self.barcordlabe_2.setGeometry(QtCore.QRect(527, 110, 500, 470))
        self.barcordlabe_2.setStyleSheet("QLabel{\n"
"    color: black;\n"
"    background-color: white;\n"
"    border: 2px solid rgb(0,0,0);\n"
"}")
        self.barcordlabe_2.setObjectName("barcordlabe_2")
        self.timelabel = QtWidgets.QLabel(parent=Form)
        self.timelabel.setGeometry(QtCore.QRect(720, 10, 271, 61))
        self.timelabel.setStyleSheet("QLabel{\n"
"    color: black;\n"
"    background-color: white;\n"
"    font-size: 14pt;  \n"
"    font-weight: bold; \n"
"}")
        self.timelabel.setObjectName("timelabel")
        self.leafletbutton_3 = QtWidgets.QPushButton(parent=Form)
        self.leafletbutton_3.setGeometry(QtCore.QRect(380, 10, 101, 60))
        self.leafletbutton_3.setStyleSheet("QPushButton{\n"
"    color: black;\n"
"    background-color: white;\n"
"    border: 2px solid rgb(58, 134, 255);\n"
"    border-radius: 20px;\n"
"    font-size: 16pt;  \n"
"    font-weight: bold; \n"
"}")
        self.leafletbutton_3.setObjectName("leafletbutton_3")

        self.retranslateUi(Form)
        self.cataloguebutton_3.clicked.connect(Form.show_second_window)
        self.cashpagebutton_3.clicked.connect(Form.show_main_window)
        self.leafletbutton_3.clicked.connect(Form.show_third_window)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.mainbutton_3.setText(_translate("Form", "메인"))
        self.cashpagebutton_3.setText(_translate("Form", "장바구니"))
        self.cataloguebutton_3.setText(_translate("Form", "위치조회"))
        self.leafletbutton_3.setText(_translate("Form", "전단지"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    FourthWindow = QtWidgets.QWidget()
    ui = Ui_FourthWindow()
    ui.setupUi(FourthWindow)
    FourthWindow.show()
    sys.exit(app.exec())

