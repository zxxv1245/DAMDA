from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_ThirdWindow(object):
    def setupUi(self, ThirdWindow):
        ThirdWindow.setObjectName("ThirdWindow")
        ThirdWindow.resize(1024, 600)
        ThirdWindow.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.centralwidget = QtWidgets.QWidget(parent=ThirdWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.imageLabel_1 = QtWidgets.QLabel(parent=self.centralwidget)
        self.imageLabel_1.setGeometry(QtCore.QRect(30, 90, 461, 461))
        self.imageLabel_1.setStyleSheet("QLabel{\n"
"    color: black;\n"
"    background-color: white;\n"
"    border: 2px solid rgb(0,0,0);\n"
"}")
        self.imageLabel_1.setObjectName("imageLabel_1")
        self.timelabel_1 = QtWidgets.QLabel(parent=self.centralwidget)
        self.timelabel_1.setGeometry(QtCore.QRect(720, 10, 271, 61))
        self.timelabel_1.setStyleSheet("QLabel{\n"
"    color: black;\n"
"    background-color: white;\n"
"    font-size: 14pt;  \n"
"    font-weight: bold; \n"
"}")
        self.timelabel_1.setObjectName("timelabel_1")
        self.mainbutton_2 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.mainbutton_2.setGeometry(QtCore.QRect(20, 10, 101, 60))
        self.mainbutton_2.setStyleSheet("QPushButton{\n"
"    color: black;\n"
"    background-color: white;\n"
"    border: 2px solid rgb(58, 134, 255);\n"
"    border-radius: 20px;\n"
"    font-size: 16pt;  \n"
"    font-weight: bold; \n"
"}")
        self.mainbutton_2.setObjectName("mainbutton_2")
        self.cashpagebutton_2 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.cashpagebutton_2.setGeometry(QtCore.QRect(140, 10, 101, 60))
        self.cashpagebutton_2.setStyleSheet("QPushButton{\n"
"    color: black;\n"
"    background-color: white;\n"
"    border: 2px solid rgb(58, 134, 255);\n"
"    border-radius: 20px;\n"
"    font-size: 16pt;  \n"
"    font-weight: bold; \n"
"}")
        self.cashpagebutton_2.setObjectName("cashpagebutton_2")
        self.cataloguebutton_2 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.cataloguebutton_2.setGeometry(QtCore.QRect(260, 10, 101, 60))
        self.cataloguebutton_2.setStyleSheet("QPushButton{\n"
"    color: black;\n"
"    background-color: white;\n"
"    border: 2px solid rgb(58, 134, 255);\n"
"    border-radius: 20px;\n"
"    font-size: 16pt;  \n"
"    font-weight: bold; \n"
"}")
        self.cataloguebutton_2.setObjectName("cataloguebutton_2")
        self.leafletbutton_2 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.leafletbutton_2.setGeometry(QtCore.QRect(380, 10, 101, 60))
        self.leafletbutton_2.setStyleSheet("QPushButton{\n"
"    color: white;\n"
"    background-color: rgb(0, 85, 255);;\n"
"    border: 2px solid rgb(58, 134, 255);\n"
"    border-radius: 20px;\n"
"    font-size: 16pt;  \n"
"    font-weight: bold; \n"
"}")
        self.leafletbutton_2.setObjectName("leafletbutton_2")
        self.imageLabel_2 = QtWidgets.QLabel(parent=self.centralwidget)
        self.imageLabel_2.setGeometry(QtCore.QRect(540, 90, 461, 461))
        self.imageLabel_2.setStyleSheet("QLabel{\n"
"    color: black;\n"
"    background-color: white;\n"
"    border: 2px solid rgb(0,0,0);\n"
"}")
        self.imageLabel_2.setObjectName("imageLabel_2")
        ThirdWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(parent=ThirdWindow)
        self.statusbar.setObjectName("statusbar")
        ThirdWindow.setStatusBar(self.statusbar)

        self.retranslateUi(ThirdWindow)
        self.mainbutton_2.clicked.connect(ThirdWindow.show_fourth_window)
        self.cataloguebutton_2.clicked.connect(ThirdWindow.show_second_window)
        self.cashpagebutton_2.clicked.connect(ThirdWindow.show_main_window)
        QtCore.QMetaObject.connectSlotsByName(ThirdWindow)

    def retranslateUi(self, ThirdWindow):
        _translate = QtCore.QCoreApplication.translate
        ThirdWindow.setWindowTitle(_translate("ThirdWindow", "MainWindow"))
        self.mainbutton_2.setText(_translate("ThirdWindow", "메인"))
        self.cashpagebutton_2.setText(_translate("ThirdWindow", "장바구니"))
        self.cataloguebutton_2.setText(_translate("ThirdWindow", "위치조회"))
        self.leafletbutton_2.setText(_translate("ThirdWindow", "전단지"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    ThirdWindow = QtWidgets.QMainWindow()
    ui = Ui_ThirdWindow()
    ui.setupUi(ThirdWindow)
    ThirdWindow.show()
    sys.exit(app.exec())
