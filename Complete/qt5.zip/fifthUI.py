from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_FifthWindow(object):
    def setupUi(self, FifthWindow):
        FifthWindow.setObjectName("FifthWindow")
        FifthWindow.resize(1024, 600)
        FifthWindow.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.centralwidget = QtWidgets.QWidget(FifthWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.qrCodeLabel = QtWidgets.QLabel(self.centralwidget)
        self.qrCodeLabel.setGeometry(QtCore.QRect(320, 110, 381, 381))
        self.qrCodeLabel.setObjectName("qrCodeLabel")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(40, 530, 231, 51))
        self.pushButton.setStyleSheet("QPushButton{\n"
"    color: black;\n"
"    background-color: white;\n"
"    border: 2px solid rgb(58, 134, 255);\n"
"    border-radius: 20px;\n"
"}")
        self.pushButton.setObjectName("pushButton")
        self.completebutton = QtWidgets.QPushButton(self.centralwidget)
        self.completebutton.setGeometry(QtCore.QRect(760, 530, 231, 51))
        self.completebutton.setStyleSheet("QPushButton{\n"
                                      "    color: black;\n"
                                      "    background-color: white;\n"
                                      "    border: 2px solid rgb(58, 134, 255);\n"
                                      "    border-radius: 20px;\n"
                                      "}")
        self.completebutton.setObjectName("completebutton")
        FifthWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(FifthWindow)
        self.pushButton.clicked.connect(FifthWindow.show_main_window)
        #self.completebutton.clicked.connect(FifthWindow.show_main_window)
        QtCore.QMetaObject.connectSlotsByName(FifthWindow)

    def retranslateUi(self, FifthWindow):
        _translate = QtCore.QCoreApplication.translate
        FifthWindow.setWindowTitle(_translate("FifthWindow", "QR 코드"))
        self.pushButton.setText(_translate("FifthWindow", "뒤로 가기"))
        self.completebutton.setText(_translate("FifthWindow", "결제 완료"))
