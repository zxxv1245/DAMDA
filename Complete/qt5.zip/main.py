import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QDialog
from PyQt5.QtGui import QPixmap, QFont, QImage
from PyQt5.QtCore import QTimer, QDateTime, Qt

from mainUI import Ui_MainWindow
from subUI import Ui_SecondWindow
from thirdUI import Ui_ThirdWindow
from fourthUI import Ui_FourthWindow
from fifthUI import Ui_FifthWindow
import qrcode
from dialogUI import Ui_Dialog
import os
import io


class ProductDialog(QDialog, Ui_Dialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)

        # 버튼 클릭 이벤트 연결
        self.pushButton.clicked.connect(self.reject)  # X 버튼 클릭 시 다이얼로그 닫기
        self.pushButton_2.clicked.connect(self.accept)  # O 버튼 클릭 시 다이얼로그 닫기


# ShoppingCartApp 클래스에 다이얼로그 호출 추가
class ShoppingCartApp(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.second_window = None
        self.third_window = None
        self.fourth_window = None
        self.fifth_window = None

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)

        self.count = 1

        # 버튼 클릭 이벤트 연결
        self.plusbutton_1.clicked.connect(self.increment_count)
        self.minusbutton_1.clicked.connect(self.decrement_count)
        self.display_product_info()

    def display_product_info(self):
        product_name = "사이다"
        price = 1100
        discount = 100
        real_price = (price - discount) * self.count
        total_price = real_price

        self.productLabel_1.setText(product_name)
        self.priceLabel_1.setText(f"{price}원")
        self.discountLabel_1.setText(f"{discount}원")
        self.countlabel_1.setText(f" {self.count}개")
        self.realPricelabel_1.setText(f"{real_price}원")
        self.totalrealPricelabel.setText(f"{total_price}원")


    def update_time(self):
        current_time = QDateTime.currentDateTime()
        formatted_time = current_time.toString("yyyy-MM-dd HH:mm:ss")
        self.timelabel.setText(formatted_time)
        self.timelabel.setAlignment(Qt.AlignCenter)

    def increment_count(self):
        self.count += 1
        self.update_count_display()

    def decrement_count(self):
        if self.count > 0:
            self.count -= 1
        self.update_count_display()

    def update_count_display(self):
        self.display_product_info()  # 변경된 count 값을 반영하여 display_product_info 호출

    def show_product_dialog(self):
        dialog = ProductDialog(self)
        result = dialog.exec_()
        if result == QDialog.Accepted:
            print("주문 확인됨")
        else:
            print("주문 취소됨")

    def show_second_window(self):
        if self.second_window is None:
            self.second_window = SecondWindow(self)
        self.hide()
        self.second_window.show()

    def show_third_window(self):
        if self.third_window is None:
            self.third_window = ThirdWindow(self)
        self.hide()
        self.third_window.show()

    def show_fourth_window(self):
        if self.fourth_window is None:
            self.fourth_window = FourthWindow(self)
        self.hide()
        self.fourth_window.show()

    def show_fifth_window(self):
        if self.fifth_window is None:
            self.fifth_window = FifthWindow(self)
        self.hide()
        self.fifth_window.show()
    def show_main_window(self):
        self.show()
class SecondWindow(QDialog, Ui_SecondWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.main_window = parent
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)  # 매 초마다 업데이트

        # 초기 텍스트 설정
        self.initial_text = {
            'maplabel_1': self.maplabel_1.text(),
            'maplabel_2': self.maplabel_2.text(),
            'maplabel_3': self.maplabel_3.text(),
            'maplabel_4': self.maplabel_4.text(),
            'maplabel_5': self.maplabel_5.text(),
            'maplabel_6': self.maplabel_6.text(),
        }

        # 버튼 클릭 연결
        self.Drinkbutton.clicked.connect(self.on_drink_button_clicked)
        self.alcolebutton.clicked.connect(self.on_alcole_button_clicked)
        self.snackbutton.clicked.connect(self.on_snack_button_clicked)
        self.housebutton.clicked.connect(self.on_house_button_clicked)
        self.icebutton.clicked.connect(self.on_ice_button_clicked)
        self.freshbutton.clicked.connect(self.on_fresh_button_clicked)

    def update_time(self):
        current_time = QDateTime.currentDateTime()

        formatted_time = current_time.toString("yyyy-MM-dd HH:mm:ss")
        self.timelabel_1.setText(formatted_time)
        self.timelabel_1.setAlignment(Qt.AlignCenter)

    def show_main_window(self):
        self.hide()
        self.main_window.show()

    def show_third_window(self):
        if self.main_window.third_window is None:
            self.main_window.third_window = ThirdWindow(self.main_window)
        self.hide()
        self.main_window.third_window.show()

    def show_fourth_window(self):
        if self.main_window.fourth_window is None:
            self.main_window.fourth_window = FourthWindow(self.main_window)
        self.hide()
        self.main_window.fourth_window.show()

    def reset_labels(self):
        default_style = "QLabel{\n" \
                        "    color: black;\n" \
                        "    background-color: white;\n" \
                        "    border: 2px solid rgb(0,0,0);\n" \
                        "}"
        default_font = QFont()
        default_font.setPointSize(48)

        self.maplabel_1.setStyleSheet(default_style)
        self.maplabel_1.setText(self.initial_text['maplabel_1'])
        self.maplabel_1.setFont(default_font)
        self.maplabel_1.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

        self.maplabel_2.setStyleSheet(default_style)
        self.maplabel_2.setText(self.initial_text['maplabel_2'])
        self.maplabel_2.setFont(default_font)
        self.maplabel_2.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

        self.maplabel_3.setStyleSheet(default_style)
        self.maplabel_3.setText(self.initial_text['maplabel_3'])
        self.maplabel_3.setFont(default_font)
        self.maplabel_3.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

        self.maplabel_4.setStyleSheet(default_style)
        self.maplabel_4.setText(self.initial_text['maplabel_4'])
        self.maplabel_4.setFont(default_font)
        self.maplabel_4.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

        self.maplabel_5.setStyleSheet(default_style)
        self.maplabel_5.setText(self.initial_text['maplabel_5'])
        self.maplabel_5.setFont(default_font)
        self.maplabel_5.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

        self.maplabel_6.setStyleSheet(default_style)
        self.maplabel_6.setText(self.initial_text['maplabel_6'])
        self.maplabel_6.setFont(default_font)
        self.maplabel_6.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

    def on_drink_button_clicked(self):
        self.reset_labels()
        self.type = "drink"
        self.change_maplabel_1_color()

    def on_alcole_button_clicked(self):
        self.reset_labels()
        self.type = "alcole"
        self.change_maplabel_2_color()

    def on_snack_button_clicked(self):
        self.reset_labels()
        self.type = "snack"
        self.change_maplabel_3_color()

    def on_house_button_clicked(self):
        self.reset_labels()
        self.type = "house"
        self.change_maplabel_4_color()

    def on_ice_button_clicked(self):
        self.reset_labels()
        self.type = "ice"
        self.change_maplabel_5_color()

    def on_fresh_button_clicked(self):
        self.reset_labels()
        self.type = "fresh"
        self.change_maplabel_6_color()

    def change_maplabel_1_color(self):
        self.maplabel_1.setStyleSheet("QLabel{\n"
                                      "    color: black;\n"
                                      "    background-color: rgb(160, 191, 250);\n"
                                      "}")
        self.maplabel_1.setText("음료")
        font = QFont()
        font.setPointSize(24)  # 텍스트 크기를 24로 줄임
        self.maplabel_1.setFont(font)
        self.maplabel_1.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

    def change_maplabel_2_color(self):
        self.maplabel_2.setStyleSheet("QLabel{\n"
                                      "    color: black;\n"
                                      "    background-color: rgb(160, 191, 250);\n"
                                      "}")
        self.maplabel_2.setText("술")
        self.maplabel_2.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

    def change_maplabel_3_color(self):
        self.maplabel_3.setStyleSheet("QLabel{\n"
                                      "    color: black;\n"
                                      "    background-color: rgb(160, 191, 250);\n"
                                      "}")
        self.maplabel_3.setText("과자")
        font = QFont()
        font.setPointSize(24)  # 텍스트 크기를 24로 줄임
        self.maplabel_3.setFont(font)
        self.maplabel_3.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

    def change_maplabel_4_color(self):
        self.maplabel_4.setStyleSheet("QLabel{\n"
                                      "    color: black;\n" 
                                      "    background-color: rgb(160, 191, 250);\n"
                                      "}")
        self.maplabel_4.setText("생활용품")
        font = QFont()
        font.setPointSize(20)  # 텍스트 크기를 20으로 줄임
        self.maplabel_4.setFont(font)
        self.maplabel_4.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

    def change_maplabel_5_color(self):
        self.maplabel_5.setStyleSheet("QLabel{\n"
                                      "    color: black;\n"
                                      "    background-color: rgb(160, 191, 250);\n"
                                      "}")
        self.maplabel_5.setText("냉동식품")
        self.maplabel_5.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

    def change_maplabel_6_color(self):
        self.maplabel_6.setStyleSheet("QLabel{\n"
                                      "    color: black;\n"
                                      "    background-color: rgb(160, 191, 250);\n"
                                      "}")
        self.maplabel_6.setText("신선식품")
        font = QFont()
        font.setPointSize(20)  # 텍스트 크기를 20으로 줄임
        self.maplabel_6.setFont(font)
        self.maplabel_6.setAlignment(Qt.AlignCenter)  # 텍스트 가운데 정렬

class ThirdWindow(QMainWindow, Ui_ThirdWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.main_window = parent

        current_directory = os.path.dirname(os.path.abspath(__file__))
          # 실제 경로로 변경하세요
        image_path1 = "./img/mart1.png"
        image_path2 = "./img/mart2.png"

        self.set_image(self.imageLabel_1, image_path1)
        self.set_image(self.imageLabel_2, image_path2)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)  # 매 초마다 업데이트

    def set_image(self, label, image_path):
        if os.path.exists(image_path):
            pixmap = QPixmap(image_path)
            label.setPixmap(pixmap)
        else:
            label.clear()

    def update_time(self):
        current_time = QDateTime.currentDateTime()
        formatted_time = current_time.toString("yyyy-MM-dd HH:mm:ss")
        self.timelabel_1.setText(formatted_time)
        self.timelabel_1.setAlignment(Qt.AlignCenter)

    def show_main_window(self):
        self.hide()
        self.main_window.show()

    def show_second_window(self):
        if self.main_window.second_window is None:
            self.main_window.second_window = SecondWindow(self.main_window)
        self.hide()
        self.main_window.second_window.show()

    def show_fourth_window(self):
        if self.main_window.fourth_window is None:
            self.main_window.fourth_window = FourthWindow(self.main_window)
        self.hide()
        self.main_window.fourth_window.show()

class FourthWindow(QMainWindow, Ui_FourthWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.main_window = parent

        current_directory = os.path.dirname(os.path.abspath(__file__))

        image_path1 = "./img/bar.png"
        image_path2 = "./img/camera.png"
        self.set_image(self.barcordlabe_1, image_path1)
        self.set_image(self.barcordlabe_2, image_path2)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)  # 매 초마다 업데이트

    def set_image(self, label, image_path):
        if os.path.exists(image_path):
            pixmap = QPixmap(image_path)
            label.setPixmap(pixmap)
        else:
            label.clear()

    def update_time(self):
        current_time = QDateTime.currentDateTime()
        formatted_time = current_time.toString("yyyy-MM-dd HH:mm:ss")
        self.timelabel.setText(formatted_time)
        self.timelabel.setAlignment(Qt.AlignCenter)

    def show_main_window(self):
        self.hide()
        self.main_window.show()

    def show_second_window(self):
        if self.main_window.second_window is None:
            self.main_window.second_window = SecondWindow(self.main_window)
        self.hide()
        self.main_window.second_window.show()

    def show_third_window(self):
        if self.main_window.third_window is None:
            self.main_window.third_window = ThirdWindow(self.main_window)
        self.hide()
        self.main_window.third_window.show()

class FifthWindow(QMainWindow, Ui_FifthWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)

        # QR 코드 생성 및 표시
        self.generate_qr_code("https://example.com")  # 예시 URL

    def generate_qr_code(self, data):
        # QR 코드 생성
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(data)
        qr.make(fit=True)
        img = qr.make_image(fill='black', back_color='white')

        # 이미지 파일을 메모리 버퍼에 저장
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')

        # 메모리 버퍼에서 QImage 생성
        buffer.seek(0)
        qimg = QImage()
        qimg.loadFromData(buffer.getvalue(), format='PNG')

        # QPixmap으로 변환하고 QLabel에 표시
        pixmap = QPixmap.fromImage(qimg)
        self.qrCodeLabel.setPixmap(pixmap)
if __name__ == '__main__':
    try:
        # DPI 스케일링 설정
        if hasattr(Qt, 'AA_EnableHighDpiScaling'):
            QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
        if hasattr(Qt, 'AA_UseHighDpiPixmaps'):
            QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

        # 환경 변수 설정
        os.environ["QT_AUTO_SCREEN_SCALE_FACTOR"] = "1"

        app = QApplication(sys.argv)
        window = ShoppingCartApp()
        window.show()
        sys.exit(app.exec())
    except Exception as e:
        print(f"Unhandled Exception: {e}")
