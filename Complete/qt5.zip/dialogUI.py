from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(400, 300)
        Dialog.setStyleSheet("background-color: rgb(255, 255, 255);")

        # label: 중앙 정렬 추가
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(40, 70, 331, 131))
        self.label.setStyleSheet("QLabel{\n"
                                 "    color: black;\n"
                                 "    background-color: white;\n"
                                 "    border: 2px solid rgb(58, 134, 255);\n"
                                 "    border-radius: 20px;\n"
                                 "    font-size: 12pt;  \n"
                                 "    font-weight: bold; \n"
                                 "}")
        self.label.setText("")
        self.label.setAlignment(QtCore.Qt.AlignCenter)  # 텍스트 가운데 정렬
        self.label.setObjectName("label")

        # label_2: 중앙 정렬 추가
        self.label_2 = QtWidgets.QLabel(Dialog)
        self.label_2.setGeometry(QtCore.QRect(40, 20, 331, 31))
        self.label_2.setStyleSheet("QLabel{\n"
                                   "    color: black;\n"
                                   "    background-color: white;\n"
                                   "    border: 2px solid rgb(58, 134, 255);\n"
                                   "    border-radius: 20px;\n"
                                   "}")
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)  # 텍스트 가운데 정렬
        self.label_2.setObjectName("label_2")
        # 취소 버튼 (pushButton): 중앙 정렬 추가
        self.pushButton = QtWidgets.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(40, 230, 101, 31))
        self.pushButton.setStyleSheet("QPushButton{\n"
                                      "    color: black;\n"
                                      "    background-color: white;\n"
                                      "    border: 2px solid rgb(0, 0, 0);\n"
                                      "    border-radius: 20px;\n"
                                      "\n"
                                      "}")
        self.pushButton.setObjectName("pushButton")

        # 확인 버튼 (pushButton_2): 중앙 정렬 추가
        self.pushButton_2 = QtWidgets.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(270, 230, 101, 31))
        self.pushButton_2.setStyleSheet("QPushButton{\n"
                                        "    color: black;\n"
                                        "    background-color: white;\n"
                                        "    border: 2px solid rgb(0, 0, 0);\n"
                                        "    border-radius: 20px;\n"
                                        "\n"
                                        "}")

        self.pushButton_2.setObjectName("pushButton_2")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label_2.setText(_translate("Dialog", "아래의 주문 정보가 맞으면 확인 틀리면 취소를 눌러주세요"))
        self.pushButton.setText(_translate("Dialog", "취소"))
        self.pushButton_2.setText(_translate("Dialog", "확인"))
