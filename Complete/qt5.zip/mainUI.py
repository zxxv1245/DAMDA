from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import Qt

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1024, 600)
        MainWindow.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.productLabel_1 = QtWidgets.QLabel(self.centralwidget)
        self.productLabel_1.setGeometry(QtCore.QRect(20, 130, 191, 40))
        self.productLabel_1.setAlignment(QtCore.Qt.AlignCenter)
        self.productLabel_1.setText("")
        self.productLabel_1.setObjectName("productLabel_1")
        self.productLabel_2 = QtWidgets.QLabel(self.centralwidget)
        self.productLabel_2.setGeometry(QtCore.QRect(20, 170, 191, 40))
        self.productLabel_2.setStyleSheet("")
        self.productLabel_2.setText("")
        self.productLabel_2.setObjectName("productLabel_2")
        self.productLabel_3 = QtWidgets.QLabel(self.centralwidget)
        self.productLabel_3.setGeometry(QtCore.QRect(20, 210, 191, 40))
        self.productLabel_3.setStyleSheet("")
        self.productLabel_3.setText("")
        self.productLabel_3.setObjectName("productLabel_3")
        self.productLabel_4 = QtWidgets.QLabel(self.centralwidget)
        self.productLabel_4.setGeometry(QtCore.QRect(20, 250, 191, 40))
        self.productLabel_4.setStyleSheet("")
        self.productLabel_4.setText("")
        self.productLabel_4.setObjectName("productLabel_4")
        self.productLabel_5 = QtWidgets.QLabel(self.centralwidget)
        self.productLabel_5.setGeometry(QtCore.QRect(20, 290, 191, 40))
        self.productLabel_5.setStyleSheet("")
        self.productLabel_5.setText("")
        self.productLabel_5.setObjectName("productLabel_5")
        self.productLabel_6 = QtWidgets.QLabel(self.centralwidget)
        self.productLabel_6.setGeometry(QtCore.QRect(20, 330, 191, 40))
        self.productLabel_6.setStyleSheet("")
        self.productLabel_6.setText("")
        self.productLabel_6.setObjectName("productLabel_6")
        self.productLabel_7 = QtWidgets.QLabel(self.centralwidget)
        self.productLabel_7.setGeometry(QtCore.QRect(20, 370, 191, 40))
        self.productLabel_7.setStyleSheet("")
        self.productLabel_7.setText("")
        self.productLabel_7.setObjectName("productLabel_7")
        self.productLabel_8 = QtWidgets.QLabel(self.centralwidget)
        self.productLabel_8.setGeometry(QtCore.QRect(20, 410, 191, 40))
        self.productLabel_8.setStyleSheet("")
        self.productLabel_8.setText("")
        self.productLabel_8.setObjectName("productLabel_8")



        self.priceLabel_1 = QtWidgets.QLabel(self.centralwidget)
        self.priceLabel_1.setGeometry(QtCore.QRect(210, 130, 191, 41))
        self.priceLabel_1.setAlignment(QtCore.Qt.AlignCenter)
        self.priceLabel_1.setText("")
        self.priceLabel_1.setObjectName("priceLabel_1")
        self.priceLabel_2 = QtWidgets.QLabel(self.centralwidget)
        self.priceLabel_2.setGeometry(QtCore.QRect(210, 170, 191, 41))
        self.priceLabel_2.setStyleSheet("")
        self.priceLabel_2.setText("")
        self.priceLabel_2.setObjectName("priceLabel_2")
        self.priceLabel_3 = QtWidgets.QLabel(self.centralwidget)
        self.priceLabel_3.setGeometry(QtCore.QRect(210, 210, 191, 41))
        self.priceLabel_3.setStyleSheet("")
        self.priceLabel_3.setText("")
        self.priceLabel_3.setObjectName("priceLabel_3")
        self.priceLabel_4 = QtWidgets.QLabel(self.centralwidget)
        self.priceLabel_4.setGeometry(QtCore.QRect(210, 250, 191, 41))
        self.priceLabel_4.setStyleSheet("")
        self.priceLabel_4.setText("")
        self.priceLabel_4.setObjectName("priceLabel_4")
        self.priceLabel_5 = QtWidgets.QLabel(self.centralwidget)
        self.priceLabel_5.setGeometry(QtCore.QRect(200, 280, 191, 41))
        self.priceLabel_5.setStyleSheet("")
        self.priceLabel_5.setText("")
        self.priceLabel_5.setObjectName("priceLabel_5")
        self.priceLabel_6 = QtWidgets.QLabel(self.centralwidget)
        self.priceLabel_6.setGeometry(QtCore.QRect(210, 320, 191, 41))
        self.priceLabel_6.setStyleSheet("")
        self.priceLabel_6.setText("")
        self.priceLabel_6.setObjectName("priceLabel_6")
        self.priceLabel_7 = QtWidgets.QLabel(self.centralwidget)
        self.priceLabel_7.setGeometry(QtCore.QRect(210, 360, 191, 41))
        self.priceLabel_7.setStyleSheet("")
        self.priceLabel_7.setText("")
        self.priceLabel_7.setObjectName("priceLabel_7")
        self.priceLabel_8 = QtWidgets.QLabel(self.centralwidget)
        self.priceLabel_8.setGeometry(QtCore.QRect(210, 400, 191, 41))
        self.priceLabel_8.setStyleSheet("")
        self.priceLabel_8.setText("")
        self.priceLabel_8.setObjectName("priceLabel_8")

        self.discountLabel_1 = QtWidgets.QLabel(self.centralwidget)
        self.discountLabel_1.setGeometry(QtCore.QRect(610, 130, 191, 41))
        self.discountLabel_1.setAlignment(QtCore.Qt.AlignCenter)
        self.discountLabel_1.setText("")
        self.discountLabel_1.setObjectName("discountLabel_1")
        self.discountLabel_2 = QtWidgets.QLabel(self.centralwidget)
        self.discountLabel_2.setGeometry(QtCore.QRect(610, 170, 191, 41))
        self.discountLabel_2.setStyleSheet("")
        self.discountLabel_2.setText("")
        self.discountLabel_2.setObjectName("discountLabel_2")
        self.discountLabel_3 = QtWidgets.QLabel(self.centralwidget)
        self.discountLabel_3.setGeometry(QtCore.QRect(610, 210, 211, 41))
        self.discountLabel_3.setStyleSheet("")
        self.discountLabel_3.setText("")
        self.discountLabel_3.setObjectName("discountLabel_3")
        self.discountLabel_4 = QtWidgets.QLabel(self.centralwidget)
        self.discountLabel_4.setGeometry(QtCore.QRect(610, 250, 211, 41))
        self.discountLabel_4.setStyleSheet("")
        self.discountLabel_4.setText("")
        self.discountLabel_4.setObjectName("discountLabel_4")
        self.discountLabel_5 = QtWidgets.QLabel(self.centralwidget)
        self.discountLabel_5.setGeometry(QtCore.QRect(610, 290, 211, 41))
        self.discountLabel_5.setStyleSheet("")
        self.discountLabel_5.setText("")
        self.discountLabel_5.setObjectName("discountLabel_5")
        self.discountLabel_6 = QtWidgets.QLabel(self.centralwidget)
        self.discountLabel_6.setGeometry(QtCore.QRect(610, 330, 211, 41))
        self.discountLabel_6.setStyleSheet("")
        self.discountLabel_6.setText("")
        self.discountLabel_6.setObjectName("discountLabel_6")
        self.discountLabel_7 = QtWidgets.QLabel(self.centralwidget)
        self.discountLabel_7.setGeometry(QtCore.QRect(610, 370, 211, 41))
        self.discountLabel_7.setStyleSheet("")
        self.discountLabel_7.setText("")
        self.discountLabel_7.setObjectName("discountLabel_7")
        self.discountLabel_8 = QtWidgets.QLabel(self.centralwidget)
        self.discountLabel_8.setGeometry(QtCore.QRect(610, 410, 211, 41))
        self.discountLabel_8.setStyleSheet("")
        self.discountLabel_8.setText("")
        self.discountLabel_8.setObjectName("discountLabel_8")

        self.realPricelabel_1 = QtWidgets.QLabel(self.centralwidget)
        self.realPricelabel_1.setGeometry(QtCore.QRect(800, 130, 191, 41))
        self.realPricelabel_1.setAlignment(QtCore.Qt.AlignCenter)
        self.realPricelabel_1.setText("")
        self.realPricelabel_1.setObjectName("realPricelabel_1")
        self.realPricelabel_2 = QtWidgets.QLabel(self.centralwidget)
        self.realPricelabel_2.setGeometry(QtCore.QRect(800, 170, 191, 41))
        self.realPricelabel_2.setStyleSheet("")
        self.realPricelabel_2.setText("")
        self.realPricelabel_2.setObjectName("realPricelabel_2")
        self.realPricelabel_3 = QtWidgets.QLabel(self.centralwidget)
        self.realPricelabel_3.setGeometry(QtCore.QRect(800, 210, 191, 41))
        self.realPricelabel_3.setStyleSheet("")
        self.realPricelabel_3.setText("")
        self.realPricelabel_3.setObjectName("realPricelabel_3")
        self.realPricelabel_4 = QtWidgets.QLabel(self.centralwidget)
        self.realPricelabel_4.setGeometry(QtCore.QRect(800, 250, 191, 41))
        self.realPricelabel_4.setStyleSheet("")
        self.realPricelabel_4.setText("")
        self.realPricelabel_4.setObjectName("realPricelabel_4")
        self.realPricelabel_5 = QtWidgets.QLabel(self.centralwidget)
        self.realPricelabel_5.setGeometry(QtCore.QRect(800, 290, 191, 41))
        self.realPricelabel_5.setStyleSheet("")
        self.realPricelabel_5.setText("")
        self.realPricelabel_5.setObjectName("realPricelabel_5")
        self.realPricelabel_6 = QtWidgets.QLabel(self.centralwidget)
        self.realPricelabel_6.setGeometry(QtCore.QRect(800, 330, 191, 41))
        self.realPricelabel_6.setStyleSheet("")
        self.realPricelabel_6.setText("")
        self.realPricelabel_6.setObjectName("realPricelabel_6")
        self.realPricelabel_7 = QtWidgets.QLabel(self.centralwidget)
        self.realPricelabel_7.setGeometry(QtCore.QRect(800, 370, 191, 41))
        self.realPricelabel_7.setStyleSheet("")
        self.realPricelabel_7.setText("")
        self.realPricelabel_7.setObjectName("realPricelabel_7")
        self.realPricelabel_8 = QtWidgets.QLabel(self.centralwidget)
        self.realPricelabel_8.setGeometry(QtCore.QRect(800, 410, 191, 41))
        self.realPricelabel_8.setStyleSheet("")
        self.realPricelabel_8.setText("")
        self.realPricelabel_8.setObjectName("realPricelabel_8")




        self.totalrealPricelabel = QtWidgets.QLabel(self.centralwidget)
        self.totalrealPricelabel.setGeometry(QtCore.QRect(620, 510, 151, 41))
        self.totalrealPricelabel.setAlignment(QtCore.Qt.AlignCenter)
        self.totalrealPricelabel.setStyleSheet("QLabel {\n"
                                         "    color: black;\n"
                                         "    background-color: white;\n"
                                         "    font-size: 16pt;  \n"
                                         "    font-weight: bold; \n"
                                         "}\n"
                                         "")
        self.totalrealPricelabel.setObjectName("totalrealPricelabel")
        self.mainbutton = QtWidgets.QPushButton(self.centralwidget)
        self.mainbutton.setGeometry(QtCore.QRect(20, 10, 101, 60))
        self.mainbutton.setStyleSheet("QPushButton{\n"
                                      "    color: black;\n"
                                      "    background-color: white;\n"
                                      "    border: 2px solid rgb(58, 134, 255);\n"
                                      "    border-radius: 20px;\n"
                                      "    font-size: 16pt;  \n"
                                      "    font-weight: bold; \n"
                                      "}")
        self.mainbutton.setObjectName("mainbutton")
        self.cataloguebutton = QtWidgets.QPushButton(self.centralwidget)
        self.cataloguebutton.setGeometry(QtCore.QRect(260, 10, 101, 60))
        self.cataloguebutton.setStyleSheet("QPushButton{\n"
                                           "    color: black;\n"
                                           "    background-color: white;\n"
                                           "    border: 2px solid rgb(58, 134, 255);\n"
                                           "    border-radius: 20px;\n"
                                           "    font-size: 16pt;  \n"
                                           "    font-weight: bold; \n"
                                           "}")
        self.cataloguebutton.setObjectName("cataloguebutton")
        self.cashbutton = QtWidgets.QPushButton(self.centralwidget)
        self.cashbutton.setGeometry(QtCore.QRect(790, 502, 197, 50))
        self.cashbutton.setStyleSheet("QPushButton{\n"
                                      "    color: black;\n"
                                      "    background-color: white;\n"
                                      "    border: 2px solid rgb(58, 134, 255);\n"
                                      "    border-radius: 20px;\n"
                                      "    font-size: 16pt;  \n"
                                      "    font-weight: bold; \n"
                                      "}")
        self.cashbutton.setObjectName("cashbutton")
        self.timelabel = QtWidgets.QLabel(self.centralwidget)
        self.timelabel.setGeometry(QtCore.QRect(720, 10, 271, 61))
        self.timelabel.setStyleSheet("QLabel{\n"
                                     "    color: black;\n"
                                     "    background-color: white;\n"
                                     "    font-size: 14pt;  \n"
"    font-weight: bold; \n"
                                     "}")
        self.timelabel.setText("")
        self.timelabel.setObjectName("timelabel")
        self.cashpagebutton = QtWidgets.QPushButton(self.centralwidget)
        self.cashpagebutton.setGeometry(QtCore.QRect(140, 10, 101, 60))
        self.cashpagebutton.setStyleSheet("QPushButton{\n"
                                          "    color: white;\n"
                                          "    background-color: rgb(0, 85, 255);\n"
                                          "    border: 2px solid rgb(58, 134, 255);\n"
                                          "    border-radius: 20px;\n"
                                          "    font-size: 16pt;  \n"
                                          "    font-weight: bold; \n"
                                          "}")
        self.cashpagebutton.setObjectName("cashpagebutton")
        self.leafletbutton = QtWidgets.QPushButton(self.centralwidget)
        self.leafletbutton.setGeometry(QtCore.QRect(380, 10, 101, 60))
        self.leafletbutton.setStyleSheet("QPushButton{\n"
                                         "    color: black;\n"
                                         "    background-color: white;\n"
                                         "    border: 2px solid rgb(58, 134, 255);\n"
                                         "    border-radius: 20px;\n"
                                         "    font-size: 16pt;  \n"
                                         "    font-weight: bold; \n"
                                         "}")
        self.leafletbutton.setObjectName("leafletbutton")

        self.plusbutton_1 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.plusbutton_1.setGeometry(QtCore.QRect(530, 140, 41, 31))
        self.plusbutton_1.setStyleSheet("QPushButton\n"
                                        "{\n"
                                        "    color: black;\n"
                                        "    background-color: white;\n"
                                        "    border: 2px solid rgb(0,0,255);\n"
                                        "}")
        self.plusbutton_1.setObjectName("plusbutton_1")
        self.plusbutton_1.hide()

        self.minusbutton_1 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.minusbutton_1.setGeometry(QtCore.QRect(570, 140, 41, 31))
        self.minusbutton_1.setStyleSheet("QPushButton\n"
                                         "{\n"
                                         "    color: black;\n"
                                         "    background-color: white;\n"
                                         "    border: 2px solid rgb(255,0,0);\n"
                                         "}")
        self.minusbutton_1.setObjectName("minusbutton_1")
        self.minusbutton_1.hide()

        self.countlabel_1 = QtWidgets.QLabel(self.centralwidget)
        self.countlabel_1.setGeometry(QtCore.QRect(400, 130, 121, 41))
        self.countlabel_1.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.countlabel_1.setStyleSheet("")
        self.countlabel_1.setText("")
        self.countlabel_1.setObjectName("countlabel_1")
        self.countlabel_2 = QtWidgets.QLabel(self.centralwidget)
        self.countlabel_2.setGeometry(QtCore.QRect(400, 170, 121, 41))
        self.countlabel_2.setStyleSheet("")
        self.countlabel_2.setText("")
        self.countlabel_2.setObjectName("countlabel_2")
        self.plusbutton_2 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.plusbutton_2.setGeometry(QtCore.QRect(530, 180, 41, 31))
        self.plusbutton_2.setStyleSheet("QPushButton\n"
                                        "{\n"
                                        "    color: black;\n"
                                        "    background-color: white;\n"
                                        "    border: 2px solid rgb(0,0,255);\n"
                                        "}")
        self.plusbutton_2.setObjectName("plusbutton_2")
        self.plusbutton_2.hide()
        self.minusbutton_2 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.minusbutton_2.setGeometry(QtCore.QRect(570, 180, 41, 31))
        self.minusbutton_2.setStyleSheet("QPushButton\n"
                                         "{\n"
                                         "    color: black;\n"
                                         "    background-color: white;\n"
                                         "    border: 2px solid rgb(255,0,0);\n"
                                         "}")
        self.minusbutton_2.setObjectName("minusbutton_2")
        self.minusbutton_2.hide()
        self.countlabel_3 = QtWidgets.QLabel(self.centralwidget)
        self.countlabel_3.setGeometry(QtCore.QRect(400, 210, 121, 41))
        self.countlabel_3.setStyleSheet("")
        self.countlabel_3.setText("")
        self.countlabel_3.setObjectName("countlabel_3")
        self.plusbutton_3 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.plusbutton_3.setGeometry(QtCore.QRect(530, 220, 41, 31))
        self.plusbutton_3.setStyleSheet("QPushButton\n"
                                        "{\n"
                                        "    color: black;\n"
                                        "    background-color: white;\n"
                                        "    border: 2px solid rgb(0,0,255);\n"
                                        "}")
        self.plusbutton_3.setObjectName("plusbutton_3")
        self.plusbutton_3.hide()
        self.minusbutton_3 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.minusbutton_3.setGeometry(QtCore.QRect(570, 220, 41, 31))
        self.minusbutton_3.setStyleSheet("QPushButton\n"
                                         "{\n"
                                         "    color: black;\n"
                                         "    background-color: white;\n"
                                         "    border: 2px solid rgb(255,0,0);\n"
                                         "}")
        self.minusbutton_3.setObjectName("minusbutton_3")
        self.minusbutton_3.hide()

        self.countlabel_4 = QtWidgets.QLabel(self.centralwidget)
        self.countlabel_4.setGeometry(QtCore.QRect(400, 250, 121, 41))
        self.countlabel_4.setStyleSheet("")
        self.countlabel_4.setText("")
        self.countlabel_4.setObjectName("countlabel_4")
        self.plusbutton_4 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.plusbutton_4.setGeometry(QtCore.QRect(530, 260, 41, 31))
        self.plusbutton_4.setStyleSheet("QPushButton\n"
                                        "{\n"
                                        "    color: black;\n"
                                        "    background-color: white;\n"
                                        "    border: 2px solid rgb(0,0,255);\n"
                                        "}")
        self.plusbutton_4.setObjectName("plusbutton_4")
        self.plusbutton_4.hide()
        self.minusbutton_4 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.minusbutton_4.setGeometry(QtCore.QRect(570, 260, 41, 31))
        self.minusbutton_4.setStyleSheet("QPushButton\n"
                                         "{\n"
                                         "    color: black;\n"
                                         "    background-color: white;\n"
                                         "    border: 2px solid rgb(255,0,0);\n"
                                         "}")
        self.minusbutton_4.setObjectName("minusbutton_4")
        self.minusbutton_4.hide()
        self.countlabel_5 = QtWidgets.QLabel(self.centralwidget)
        self.countlabel_5.setGeometry(QtCore.QRect(400, 290, 121, 41))
        self.countlabel_5.setStyleSheet("")
        self.countlabel_5.setText("")
        self.countlabel_5.setObjectName("countlabel_5")
        self.plusbutton_5 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.plusbutton_5.setGeometry(QtCore.QRect(530, 300, 41, 31))
        self.plusbutton_5.setStyleSheet("QPushButton\n"
                                        "{\n"
                                        "    color: black;\n"
                                        "    background-color: white;\n"
                                        "    border: 2px solid rgb(0,0,255);\n"
                                        "}")
        self.plusbutton_5.setObjectName("plusbutton_5")
        self.plusbutton_5.hide()
        self.minusbutton_5 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.minusbutton_5.setGeometry(QtCore.QRect(570, 300, 41, 31))
        self.minusbutton_5.setStyleSheet("QPushButton\n"
                                         "{\n"
                                         "    color: black;\n"
                                         "    background-color: white;\n"
                                         "    border: 2px solid rgb(255,0,0);\n"
                                         "}")
        self.minusbutton_5.setObjectName("minusbutton_5")
        self.minusbutton_5.hide()
        self.countlabel_6 = QtWidgets.QLabel(self.centralwidget)
        self.countlabel_6.setGeometry(QtCore.QRect(400, 330, 121, 41))
        self.countlabel_6.setStyleSheet("")
        self.countlabel_6.setText("")
        self.countlabel_6.setObjectName("countlabel_6")
        self.plusbutton_6 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.plusbutton_6.setGeometry(QtCore.QRect(530, 340, 41, 31))
        self.plusbutton_6.setStyleSheet("QPushButton\n"
                                        "{\n"
                                        "    color: black;\n"
                                        "    background-color: white;\n"
                                        "    border: 2px solid rgb(0,0,255);\n"
                                        "}")
        self.plusbutton_6.setObjectName("plusbutton_6")
        self.plusbutton_6.hide()
        self.minusbutton_6 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.minusbutton_6.setGeometry(QtCore.QRect(570, 340, 41, 31))
        self.minusbutton_6.setStyleSheet("QPushButton\n"
                                         "{\n"
                                         "    color: black;\n"
                                         "    background-color: white;\n"
                                         "    border: 2px solid rgb(255,0,0);\n"
                                         "}")
        self.minusbutton_6.setObjectName("minusbutton_6")
        self.minusbutton_6.hide()
        self.countlabel_7 = QtWidgets.QLabel(self.centralwidget)
        self.countlabel_7.setGeometry(QtCore.QRect(400, 370, 121, 41))
        self.countlabel_7.setStyleSheet("")
        self.countlabel_7.setText("")
        self.countlabel_7.setObjectName("countlabel_7")
        self.plusbutton_7 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.plusbutton_7.setGeometry(QtCore.QRect(530, 380, 41, 31))
        self.plusbutton_7.setStyleSheet("QPushButton\n"
                                        "{\n"
                                        "    color: black;\n"
                                        "    background-color: white;\n"
                                        "    border: 2px solid rgb(0,0,255);\n"
                                        "}")
        self.plusbutton_7.setObjectName("plusbutton_7")
        self.plusbutton_7.hide()
        self.minusbutton_7 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.minusbutton_7.setGeometry(QtCore.QRect(570, 380, 41, 31))
        self.minusbutton_7.setStyleSheet("QPushButton\n"
                                         "{\n"
                                         "    color: black;\n"
                                         "    background-color: white;\n"
                                         "    border: 2px solid rgb(255,0,0);\n"
                                         "}")
        self.minusbutton_7.setObjectName("minusbutton_7")
        self.minusbutton_7.hide()
        self.countlabel_8 = QtWidgets.QLabel(self.centralwidget)
        self.countlabel_8.setGeometry(QtCore.QRect(400, 410, 121, 41))
        self.countlabel_8.setStyleSheet("")
        self.countlabel_8.setText("")
        self.countlabel_8.setObjectName("countlabel_8")
        self.plusbutton_8 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.plusbutton_8.setGeometry(QtCore.QRect(530, 420, 41, 31))
        self.plusbutton_8.setStyleSheet("QPushButton\n"
                                        "{\n"
                                        "    color: black;\n"
                                        "    background-color: white;\n"
                                        "    border: 2px solid rgb(0,0,255);\n"
                                        "}")
        self.plusbutton_8.setObjectName("plusbutton_8")
        self.plusbutton_8.hide()
        self.minusbutton_8 = QtWidgets.QPushButton(parent=self.centralwidget)
        self.minusbutton_8.setGeometry(QtCore.QRect(570, 420, 41, 31))
        self.minusbutton_8.setStyleSheet("QPushButton\n"
                                         "{\n"
                                         "    color: black;\n"
                                         "    background-color: white;\n"
                                         "    border: 2px solid rgb(255,0,0);\n"
                                         "}")
        self.minusbutton_8.setObjectName("minusbutton_8")
        self.minusbutton_8.hide()
        self.topcountlabel = QtWidgets.QLabel(self.centralwidget)
        self.topcountlabel.setGeometry(QtCore.QRect(410, 90, 200, 40))
        self.topcountlabel.setStyleSheet("QLabel {\n"
                                         "    color: black;\n"
                                         "    background-color: white;\n"
                                         "    border-top: 2px solid rgb(58, 134, 255);\n"
                                         "    border-left: none;  \n"
                                         "    border-bottom: 2px solid rgb(58, 134, 255);  \n"
                                         "    border-right: none;  \n"
                                         "    font-size: 16pt;  \n"
                                         "    font-weight: bold; \n"
                                         "}\n"
                                         "")
        self.topcountlabel.setAlignment(QtCore.Qt.AlignCenter)
        self.topcountlabel.setObjectName("topcountlabel")
        self.topdiscountlabel = QtWidgets.QLabel(self.centralwidget)
        self.topdiscountlabel.setGeometry(QtCore.QRect(610, 90, 197, 40))
        self.topdiscountlabel.setStyleSheet("QLabel {\n"
                                            "    color: black;\n"
                                            "    background-color: white;\n"
                                            "    border-top: 2px solid rgb(58, 134, 255);\n"
                                            "    border-left: none;  \n"
                                            "    border-bottom: 2px solid rgb(58, 134, 255);  \n"
                                            "    border-right: none;  \n"
                                            "    font-size: 16pt;  \n"
                                            "    font-weight: bold; \n"
                                            "}\n"
                                            "")
        self.topdiscountlabel.setAlignment(QtCore.Qt.AlignCenter)
        self.topdiscountlabel.setObjectName("topdiscountlabel")
        self.topproductLabel = QtWidgets.QLabel(self.centralwidget)
        self.topproductLabel.setGeometry(QtCore.QRect(18, 90, 197, 40))
        self.topproductLabel.setStyleSheet("QLabel {\n"
                                           "    color: black;\n"
                                           "    background-color: white;\n"
                                           "    border-top: 2px solid rgb(58, 134, 255);\n"
                                           "    border-left: 2px solid rgb(58, 134, 255);  \n"
                                           "    border-bottom: 2px solid rgb(58, 134, 255);  \n"
                                           "    border-right: none;  \n"
                                           "    font-size: 16pt;  \n"
                                           "    font-weight: bold; \n"
                                           "}\n"
                                           "")
        self.topproductLabel.setAlignment(QtCore.Qt.AlignCenter)
        self.topproductLabel.setObjectName("topproductLabel")
        self.toppriceLabel = QtWidgets.QLabel(self.centralwidget)
        self.toppriceLabel.setGeometry(QtCore.QRect(210, 90, 200, 40))
        self.toppriceLabel.setStyleSheet("QLabel {\n"
                                         "    color: black;\n"
                                         "    background-color: white;\n"
                                         "    border-top: 2px solid rgb(58, 134, 255);\n"
                                         "    border-left: none;  \n"
                                         "    border-bottom: 2px solid rgb(58, 134, 255);  \n"
                                         "    border-right: none;  \n"
                                         "    font-size: 16pt;  \n"
                                         "    font-weight: bold; \n"
                                         "}\n"
                                         "")
        self.toppriceLabel.setAlignment(QtCore.Qt.AlignCenter)
        self.toppriceLabel.setObjectName("toppriceLabel")
        self.toprealPricelabel = QtWidgets.QLabel(self.centralwidget)
        self.toprealPricelabel.setGeometry(QtCore.QRect(802, 90, 197, 40))
        self.toprealPricelabel.setStyleSheet("QLabel {\n"
                                             "    color: black;\n"
                                             "    background-color: white;\n"
                                             "    border-top: 2px solid rgb(58, 134, 255);\n"
                                             "    border-left: none;  \n"
                                             "    border-bottom: 2px solid rgb(58, 134, 255);  \n"
                                             "    border-right:  2px solid rgb(58, 134, 255);  \n"
                                             "    font-size: 16pt;  \n"
                                             "    font-weight: bold; \n"
                                             "}\n"
                                             "")
        self.toprealPricelabel.setAlignment(QtCore.Qt.AlignCenter)
        self.toprealPricelabel.setObjectName("toprealPricelabel")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(18, 127, 981, 371))
        self.label.setStyleSheet("QLabel {\n"
                                 "    color: black;\n"
                                 "    background-color: white;\n"
                                 "    border-top: none;\n"
                                 "    border-left: 2px solid rgb(58, 134, 255);  \n"
                                 "    border-bottom: 2px solid rgb(58, 134, 255);  \n"
                                 "    border-right: 2px solid rgb(58, 134, 255);  \n"
                                 "}\n"
                                 "")
        self.label.setText("")
        self.label.setObjectName("label")
        self.cleanbutton = QtWidgets.QPushButton(self.centralwidget)
        self.cleanbutton.setGeometry(QtCore.QRect(20, 502, 197, 50))
        self.cleanbutton.setStyleSheet("QPushButton{\n"
                                       "    color: black;\n"
                                       "    background-color: white;\n"
                                       "    border: 2px solid rgb(58, 134, 255);\n"
                                       "    border-radius: 20px;\n"
                                       "    font-size: 16pt;  \n"
                                       "    font-weight: bold; \n"
                                       "}")
        self.cleanbutton.setObjectName("cleanbutton")
        self.label.raise_()
        self.productLabel_1.raise_()
        self.priceLabel_1.raise_()
        self.discountLabel_1.raise_()
        self.realPricelabel_1.raise_()
        self.productLabel_2.raise_()
        self.priceLabel_2.raise_()
        self.discountLabel_2.raise_()
        self.realPricelabel_2.raise_()
        self.productLabel_3.raise_()
        self.productLabel_4.raise_()
        self.realPricelabel_4.raise_()
        self.discountLabel_3.raise_()
        self.priceLabel_4.raise_()
        self.discountLabel_4.raise_()
        self.realPricelabel_3.raise_()
        self.priceLabel_3.raise_()
        self.productLabel_5.raise_()
        self.productLabel_6.raise_()
        self.realPricelabel_6.raise_()
        self.discountLabel_5.raise_()
        self.priceLabel_6.raise_()
        self.discountLabel_6.raise_()
        self.realPricelabel_5.raise_()
        self.priceLabel_5.raise_()
        self.productLabel_7.raise_()
        self.discountLabel_7.raise_()
        self.realPricelabel_7.raise_()
        self.priceLabel_7.raise_()
        self.totalrealPricelabel.raise_()
        self.mainbutton.raise_()
        self.cataloguebutton.raise_()
        self.cashbutton.raise_()
        self.timelabel.raise_()
        self.cashpagebutton.raise_()
        self.leafletbutton.raise_()
        self.productLabel_8.raise_()
        self.priceLabel_8.raise_()
        self.discountLabel_8.raise_()
        self.realPricelabel_8.raise_()
        self.plusbutton_1.raise_()
        self.minusbutton_1.raise_()
        self.countlabel_1.raise_()
        self.countlabel_2.raise_()
        self.plusbutton_2.raise_()
        self.minusbutton_2.raise_()
        self.countlabel_3.raise_()
        self.plusbutton_3.raise_()
        self.minusbutton_3.raise_()
        self.countlabel_4.raise_()
        self.plusbutton_4.raise_()
        self.minusbutton_4.raise_()
        self.countlabel_5.raise_()
        self.plusbutton_5.raise_()
        self.minusbutton_5.raise_()
        self.countlabel_6.raise_()
        self.plusbutton_6.raise_()
        self.minusbutton_6.raise_()
        self.countlabel_7.raise_()
        self.plusbutton_7.raise_()
        self.minusbutton_7.raise_()
        self.countlabel_8.raise_()
        self.plusbutton_8.raise_()
        self.minusbutton_8.raise_()
        self.topcountlabel.raise_()
        self.topdiscountlabel.raise_()
        self.topproductLabel.raise_()
        self.toppriceLabel.raise_()
        self.toprealPricelabel.raise_()
        self.cleanbutton.raise_()
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        self.mainbutton.clicked.connect(MainWindow.show_fourth_window) # type: ignore
        self.cataloguebutton.clicked.connect(MainWindow.show_second_window) # type: ignore
        self.cashpagebutton.clicked.connect(MainWindow.show_main_window) # type: ignore
        self.leafletbutton.clicked.connect(MainWindow.show_third_window) # type: ignore
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.totalrealPricelabel.setText(_translate("MainWindow", "최종금액"))
        self.mainbutton.setText(_translate("MainWindow", "메인"))
        self.cataloguebutton.setText(_translate("MainWindow", "위치조회"))
        self.cashbutton.setText(_translate("MainWindow", "결제 하기"))
        self.cashpagebutton.setText(_translate("MainWindow", "장바구니"))
        self.leafletbutton.setText(_translate("MainWindow", "전단지"))
        self.plusbutton_1.setText(_translate("MainWindow", "+"))
        self.minusbutton_1.setText(_translate("MainWindow", "-"))
        self.plusbutton_2.setText(_translate("MainWindow", "+"))
        self.minusbutton_2.setText(_translate("MainWindow", "-"))
        self.plusbutton_3.setText(_translate("MainWindow", "+"))
        self.minusbutton_3.setText(_translate("MainWindow", "-"))
        self.plusbutton_4.setText(_translate("MainWindow", "+"))
        self.minusbutton_4.setText(_translate("MainWindow", "-"))
        self.plusbutton_5.setText(_translate("MainWindow", "+"))
        self.minusbutton_5.setText(_translate("MainWindow", "-"))
        self.plusbutton_6.setText(_translate("MainWindow", "+"))
        self.minusbutton_6.setText(_translate("MainWindow", "-"))
        self.plusbutton_7.setText(_translate("MainWindow", "+"))
        self.minusbutton_7.setText(_translate("MainWindow", "-"))
        self.plusbutton_8.setText(_translate("MainWindow", "+"))
        self.minusbutton_8.setText(_translate("MainWindow", "-"))
        self.topcountlabel.setText(_translate("MainWindow", "수량"))
        self.topdiscountlabel.setText(_translate("MainWindow", "할인"))
        self.topproductLabel.setText(_translate("MainWindow", "상품 이름"))
        self.toppriceLabel.setText(_translate("MainWindow", "판매가"))
        self.toprealPricelabel.setText(_translate("MainWindow", "합계"))
        self.cleanbutton.setText(_translate("MainWindow", "장바구니 비우기"))
